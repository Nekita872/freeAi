package com.geofree.android.data

data class AiService(
    val id: String,
    val name: String,
    val domains: List<String>,
    var enabled: Boolean = true
)

object AiCatalog {
    val services: List<AiService> = listOf(
        AiService(
            "chatgpt",
            "ChatGPT / OpenAI",
            listOf(
                "chatgpt.com", "ab.chatgpt.com", "webrtc.chatgpt.com",
                "tcr9i.chat.openai.com", "auth.openai.com", "platform.openai.com",
                "api.openai.com", "cdn.oaistatic.com", "files.oaiusercontent.com",
                "auth0.openai.com", "cdn.auth0.com"
            )
        ),
        AiService(
            "gemini",
            "Google Gemini / AI Studio",
            listOf(
                "gemini.google.com", "aistudio.google.com", "labs.google.com",
                "generativelanguage.googleapis.com", "aisandbox-pa.googleapis.com",
                "alkalimakersuite-pa.clients6.google.com", "aitestkitchen.withgoogle.com"
            )
        ),
        AiService(
            "claude",
            "Claude / Anthropic",
            listOf("claude.ai", "anthropic.com", "api.anthropic.com")
        ),
        AiService(
            "grok",
            "Grok / xAI",
            listOf("x.ai", "grok.com", "accounts.x.ai")
        ),
        AiService(
            "copilot",
            "Microsoft Copilot",
            listOf("copilot.microsoft.com", "sydney.bing.com", "edgeservices.bing.com")
        )
    )

    fun enabledDomains(): List<String> =
        services.filter { it.enabled }.flatMap { it.domains }.distinct()
}
