package com.geofree.android.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class IpGroup(
    val id: String,
    var name: String,
    val builtin: Boolean,
    val ips: MutableList<String> = mutableListOf()
)

/**
 * Группы IP + карта domain→ip, всё в SharedPreferences (JSON).
 */
class IpGroupStore(context: Context) {
    private val sp = context.getSharedPreferences("freeai_groups", Context.MODE_PRIVATE)

    fun ensureDefaults() {
        if (sp.contains("inited")) return
        val groups = defaultGroups()
        saveGroups(groups)
        sp.edit().putBoolean("inited", true).apply()
    }

    fun loadGroups(): MutableList<IpGroup> {
        ensureDefaults()
        val raw = sp.getString("groups_json", null) ?: return defaultGroups().toMutableList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<IpGroup>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ipsArr = o.optJSONArray("ips") ?: JSONArray()
                val ips = mutableListOf<String>()
                for (j in 0 until ipsArr.length()) ips.add(ipsArr.getString(j))
                out.add(
                    IpGroup(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        builtin = o.optBoolean("builtin", false),
                        ips = ips
                    )
                )
            }
            if (out.isEmpty()) defaultGroups().toMutableList() else out
        } catch (_: Exception) {
            defaultGroups().toMutableList()
        }
    }

    fun saveGroups(groups: List<IpGroup>) {
        val arr = JSONArray()
        for (g in groups) {
            val o = JSONObject()
            o.put("id", g.id)
            o.put("name", g.name)
            o.put("builtin", g.builtin)
            val ips = JSONArray()
            g.ips.forEach { ips.put(it) }
            o.put("ips", ips)
            arr.put(o)
        }
        sp.edit().putString("groups_json", arr.toString()).apply()
    }

    fun allIps(): List<String> =
        loadGroups().flatMap { it.ips }.map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    fun mergeIpsIntoGroup(groupId: String, newIps: Collection<String>) {
        val groups = loadGroups()
        val g = groups.find { it.id == groupId } ?: return
        for (ip in newIps) {
            val t = ip.trim()
            if (t.isNotEmpty() && t !in g.ips) g.ips.add(t)
        }
        saveGroups(groups)
    }

    fun mergeResolved(domainToIp: Map<String, String>) {
        val groups = loadGroups()
        fun add(groupId: String, ip: String) {
            val g = groups.find { it.id == groupId } ?: return
            if (ip.isNotBlank() && ip !in g.ips) g.ips.add(ip)
        }
        for ((dom, ip) in domainToIp) {
            val d = dom.lowercase()
            when {
                d.contains("openai") || d.contains("chatgpt") || d.contains("oaistatic") ||
                    d.contains("oaiusercontent") || d.contains("auth0") -> add("chatgpt", ip)
                d.contains("grok") || d == "x.ai" || d.endsWith(".x.ai") -> add("grok", ip)
                d.contains("claude") || d.contains("anthropic") -> add("other", ip)
                d.contains("gemini") || d.contains("google") || d.contains("aistudio") -> add("other", ip)
                d.contains("copilot") || d.contains("bing") || d.contains("microsoft") -> add("other", ip)
                else -> add("other", ip)
            }
        }
        saveGroups(groups)
    }

    companion object {
        fun defaultGroups(): List<IpGroup> = listOf(
            IpGroup(
                "chatgpt", "ChatGPT / OpenAI", true,
                mutableListOf(
                    "206.223.251.18", "157.22.181.209", "199.189.255.234", "206.223.246.75"
                )
            ),
            IpGroup(
                "grok", "Grok / xAI", true,
                mutableListOf(
                    "206.223.251.18", "157.22.181.209", "199.189.255.234", "206.223.246.75"
                )
            ),
            IpGroup(
                "other", "Другие AI", true,
                mutableListOf(
                    "91.207.75.110", "85.137.95.246", "94.250.253.55", "212.109.195.93"
                )
            )
        )
    }
}
