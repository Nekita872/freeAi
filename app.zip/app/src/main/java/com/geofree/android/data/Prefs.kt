package com.geofree.android.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("geofree", Context.MODE_PRIVATE)

    var selectedIp: String
        get() = sp.getString("ip", IpPool.DEFAULT) ?: IpPool.DEFAULT
        set(v) = sp.edit().putString("ip", v).apply()

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    fun isServiceOn(id: String): Boolean = sp.getBoolean("svc_$id", true)

    fun setServiceOn(id: String, on: Boolean) {
        sp.edit().putBoolean("svc_$id", on).apply()
    }

    fun loadServiceFlags() {
        AiCatalog.services.forEach { it.enabled = isServiceOn(it.id) }
    }

    fun saveServiceFlags() {
        val e = sp.edit()
        AiCatalog.services.forEach { e.putBoolean("svc_${it.id}", it.enabled) }
        e.apply()
    }

    fun saveDomainMap(map: Map<String, String>) {
        val e = sp.edit()
        e.putStringSet("dom_keys", map.keys)
        map.forEach { (d, ip) -> e.putString("dom_$d", ip) }
        e.apply()
    }

    fun loadDomainMap(): Map<String, String> {
        val keys = sp.getStringSet("dom_keys", emptySet()) ?: emptySet()
        val out = linkedMapOf<String, String>()
        for (d in keys) {
            val ip = sp.getString("dom_$d", null) ?: continue
            out[d.lowercase()] = ip
        }
        return out
    }
}
