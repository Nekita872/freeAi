package com.geofree.android.root

import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader

/**
 * Правка /system/etc/hosts через su (нужен root).
 * Логика как у GeoFree: бэкап → удаление старых записей наших доменов → запись новых → сброс DNS.
 */
object RootHosts {

    private const val HOSTS = "/system/etc/hosts"
    private const val BACKUP = "/system/etc/hosts.geofree.bak"
    private const val MARKER = "# GeoFreeAndroid"

    fun isRootAvailable(): Boolean {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val out = BufferedReader(InputStreamReader(p.inputStream)).readText()
            p.waitFor()
            out.contains("uid=0")
        } catch (_: Exception) {
            false
        }
    }

    fun apply(ip: String, domains: List<String>): Result<String> {
        if (domains.isEmpty()) return Result.failure(IllegalStateException("Не выбран ни один сервис"))
        return try {
            val script = buildString {
                appendLine("mount -o rw,remount /system 2>/dev/null || mount -o rw,remount / 2>/dev/null || true")
                appendLine("[ -f $BACKUP ] || cp $HOSTS $BACKUP")
                appendLine("cp $HOSTS /data/local/tmp/hosts.geofree.work")
                appendLine("grep -v '$MARKER' /data/local/tmp/hosts.geofree.work > /data/local/tmp/hosts.geofree.clean || true")
                // remove previous lines for our domains
                for (d in domains) {
                    appendLine("grep -vE '[[:space:]]$d([[:space:]]|\$)' /data/local/tmp/hosts.geofree.clean > /data/local/tmp/hosts.geofree.tmp && mv /data/local/tmp/hosts.geofree.tmp /data/local/tmp/hosts.geofree.clean")
                }
                appendLine("echo '' >> /data/local/tmp/hosts.geofree.clean")
                appendLine("echo '$MARKER' >> /data/local/tmp/hosts.geofree.clean")
                for (d in domains) {
                    appendLine("echo '$ip $d' >> /data/local/tmp/hosts.geofree.clean")
                }
                appendLine("cp /data/local/tmp/hosts.geofree.clean $HOSTS")
                appendLine("chmod 644 $HOSTS")
                appendLine("ndc resolver flushdefaultif 2>/dev/null || true")
                appendLine("ndc resolver flushnet 2>/dev/null || true")
                // Android private DNS / cache
                appendLine("settings put global private_dns_mode off 2>/dev/null || true")
            }
            val out = su(script)
            Result.success("hosts обновлён → $ip (${domains.size} доменов)\n$out")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun restore(): Result<String> {
        return try {
            val script = """
                mount -o rw,remount /system 2>/dev/null || mount -o rw,remount / 2>/dev/null || true
                if [ -f $BACKUP ]; then
                  cp $BACKUP $HOSTS
                  chmod 644 $HOSTS
                  echo restored_from_backup
                else
                  grep -v '$MARKER' $HOSTS > /data/local/tmp/hosts.geofree.clean || true
                  # strip lines we may have added without marker on old runs — best effort
                  cp /data/local/tmp/hosts.geofree.clean $HOSTS
                  chmod 644 $HOSTS
                  echo restored_without_backup
                fi
                ndc resolver flushdefaultif 2>/dev/null || true
            """.trimIndent()
            val out = su(script)
            Result.success("hosts восстановлен\n$out")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun isApplied(): Boolean {
        return try {
            val out = su("grep -c '$MARKER' $HOSTS 2>/dev/null || echo 0")
            out.trim().toIntOrNull()?.let { it > 0 } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private fun su(script: String): String {
        val process = Runtime.getRuntime().exec("su")
        DataOutputStream(process.outputStream).use { os ->
            os.writeBytes(script)
            os.writeBytes("\nexit\n")
            os.flush()
        }
        val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
        val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
        val code = process.waitFor()
        if (code != 0 && stdout.isBlank() && stderr.isNotBlank()) {
            throw RuntimeException("su exit $code: $stderr")
        }
        return (stdout + stderr).trim()
    }
}
