package com.geofree.android.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.geofree.android.R
import com.geofree.android.data.IpGroup
import com.geofree.android.data.IpGroupStore
import com.geofree.android.data.Prefs
import com.geofree.android.databinding.FragmentIpsBinding
import com.geofree.android.util.IpTester
import kotlinx.coroutines.launch
import java.util.UUID

class IpsFragment : Fragment() {

    private var _b: FragmentIpsBinding? = null
    private val b get() = _b!!
    private lateinit var prefs: Prefs
    private lateinit var store: IpGroupStore
    private var groups: MutableList<IpGroup> = mutableListOf()
    private var selectedGroupId: String = "chatgpt"
    private val latencyMap = mutableMapOf<String, String>()
    private lateinit var adapter: GroupAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentIpsBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        prefs = Prefs(requireContext())
        store = IpGroupStore(requireContext())
        groups = store.loadGroups()
        if (groups.none { it.id == selectedGroupId }) {
            selectedGroupId = groups.firstOrNull()?.id ?: "chatgpt"
        }
        b.etIp.setText(prefs.selectedIp)

        b.rvIps.layoutManager = LinearLayoutManager(requireContext())
        adapter = GroupAdapter(
            groupsProvider = { groups },
            selectedId = { selectedGroupId },
            latency = latencyMap,
            onSelectGroup = {
                selectedGroupId = it
                adapter.notifyDataSetChanged()
            },
            onSelectIp = { ip ->
                prefs.selectedIp = ip
                b.etIp.setText(ip)
                Toast.makeText(requireContext(), "Fallback: $ip", Toast.LENGTH_SHORT).show()
            },
            onDeleteIp = { groupId, ip ->
                val g = groups.find { it.id == groupId } ?: return@GroupAdapter
                g.ips.remove(ip)
                store.saveGroups(groups)
                refreshList()
            },
            onRenameGroup = { g -> promptRename(g) },
            onDeleteGroup = { g ->
                if (g.builtin) {
                    Toast.makeText(requireContext(), "Встроенную группу нельзя удалить", Toast.LENGTH_SHORT).show()
                    return@GroupAdapter
                }
                groups.removeAll { it.id == g.id }
                store.saveGroups(groups)
                if (selectedGroupId == g.id) selectedGroupId = groups.firstOrNull()?.id ?: "chatgpt"
                refreshList()
            }
        )
        b.rvIps.adapter = adapter

        b.btnApplyIp.setOnClickListener {
            val ip = b.etIp.text?.toString()?.trim().orEmpty()
            if (ip.isBlank()) {
                Toast.makeText(requireContext(), "Введите IP", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // простой фильтр IPv4
            val parts = ip.split('.')
            if (parts.size != 4 || parts.any { it.toIntOrNull() !in 0..255 }) {
                Toast.makeText(requireContext(), "Некорректный IP", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            var g = groups.find { it.id == selectedGroupId }
            if (g == null) {
                selectedGroupId = groups.firstOrNull()?.id ?: return@setOnClickListener
                g = groups.find { it.id == selectedGroupId }
            }
            if (g == null) {
                Toast.makeText(requireContext(), "Нет группы", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (ip !in g.ips) g.ips.add(ip)
            prefs.selectedIp = ip
            store.saveGroups(groups)
            groups = store.loadGroups()
            refreshList()
            Toast.makeText(requireContext(), "Добавлено в «${g.name}»", Toast.LENGTH_SHORT).show()
        }

        b.btnAddGroup.setOnClickListener { promptNewGroup() }

        b.btnTest.setOnClickListener {
            lifecycleScope.launch {
                b.tvTestLog.text = "Тест TCP 443…"
                val lines = StringBuilder()
                val all = groups.flatMap { it.ips }.distinct()
                if (all.isEmpty()) {
                    b.tvTestLog.text = "Нет IP для теста"
                    return@launch
                }
                for (ip in all) {
                    val r = IpTester.test(ip)
                    val mark = if (r.ok) "OK" else "FAIL"
                    lines.appendLine("$mark $ip ${r.latencyMs}ms ${r.note}")
                    latencyMap[ip] = if (r.ok) "${r.latencyMs}ms" else "fail"
                    adapter.notifyDataSetChanged()
                }
                b.tvTestLog.text = lines.toString()
            }
        }

        b.btnAuto.setOnClickListener {
            lifecycleScope.launch {
                b.tvTestLog.text = "Авто-подбор через Smart DNS…\n(freeAi лучше выключить)"
                val map = try {
                    IpTester.resolveDomainMap()
                } catch (e: Exception) {
                    b.tvTestLog.text = "Ошибка: ${e.message}"
                    return@launch
                }
                if (map.isEmpty()) {
                    b.tvTestLog.text = "Пусто. Выключи freeAi и повтори."
                    return@launch
                }
                prefs.saveDomainMap(prefs.loadDomainMap() + map)
                store.mergeResolved(map)
                groups = store.loadGroups()
                refreshList()
                val lines = StringBuilder("Добавлено / обновлено:\n")
                map.forEach { (d, ip) -> lines.appendLine("$d → $ip") }
                lines.appendLine("\nСтарые IP сохранены.")
                b.tvTestLog.text = lines.toString()
                map.values.firstOrNull()?.let {
                    prefs.selectedIp = it
                    b.etIp.setText(it)
                }
                Toast.makeText(requireContext(), "Карта: ${map.size} доменов", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun refreshList() {
        adapter.notifyDataSetChanged()
    }

    private fun promptNewGroup() {
        val input = EditText(requireContext())
        input.hint = "Название группы"
        AlertDialog.Builder(requireContext())
            .setTitle("Новая группа")
            .setView(input)
            .setPositiveButton("Создать") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                val id = "u_" + UUID.randomUUID().toString().take(8)
                groups.add(IpGroup(id, name, false, mutableListOf()))
                selectedGroupId = id
                store.saveGroups(groups)
                groups = store.loadGroups()
                refreshList()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun promptRename(g: IpGroup) {
        val input = EditText(requireContext())
        input.setText(g.name)
        AlertDialog.Builder(requireContext())
            .setTitle("Переименовать")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                g.name = name
                store.saveGroups(groups)
                groups = store.loadGroups()
                refreshList()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private sealed class Row {
        data class Header(val group: IpGroup) : Row()
        data class Ip(val groupId: String, val ip: String) : Row()
    }

    private class GroupAdapter(
        private val groupsProvider: () -> List<IpGroup>,
        private val selectedId: () -> String,
        private val latency: Map<String, String>,
        private val onSelectGroup: (String) -> Unit,
        private val onSelectIp: (String) -> Unit,
        private val onDeleteIp: (String, String) -> Unit,
        private val onRenameGroup: (IpGroup) -> Unit,
        private val onDeleteGroup: (IpGroup) -> Unit
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        private fun rows(): List<Row> {
            val out = mutableListOf<Row>()
            for (g in groupsProvider()) {
                out.add(Row.Header(g))
                for (ip in g.ips) out.add(Row.Ip(g.id, ip))
            }
            return out
        }

        override fun getItemViewType(position: Int) = when (rows()[position]) {
            is Row.Header -> 0
            is Row.Ip -> 1
        }

        override fun getItemCount() = rows().size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inf = LayoutInflater.from(parent.context)
            return if (viewType == 0) {
                object : RecyclerView.ViewHolder(inf.inflate(R.layout.item_group_header, parent, false)) {}
            } else {
                object : RecyclerView.ViewHolder(inf.inflate(R.layout.item_ip, parent, false)) {}
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val row = rows()[position]) {
                is Row.Header -> {
                    val name = holder.itemView.findViewById<TextView>(R.id.tvGroupName)
                    val ren = holder.itemView.findViewById<TextView>(R.id.tvRename)
                    val del = holder.itemView.findViewById<TextView>(R.id.tvDeleteGroup)
                    val sel = row.group.id == selectedId()
                    name.text = (if (sel) "● " else "○ ") + row.group.name + " (${row.group.ips.size})"
                    name.setOnClickListener { onSelectGroup(row.group.id) }
                    ren.setOnClickListener { onRenameGroup(row.group) }
                    del.visibility = if (row.group.builtin) View.INVISIBLE else View.VISIBLE
                    del.setOnClickListener { onDeleteGroup(row.group) }
                }
                is Row.Ip -> {
                    val tv = holder.itemView.findViewById<TextView>(R.id.tvIp)
                    val lat = holder.itemView.findViewById<TextView>(R.id.tvLatency)
                    val del = holder.itemView.findViewById<TextView>(R.id.tvDeleteIp)
                    tv.text = row.ip
                    lat.text = latency[row.ip] ?: ""
                    holder.itemView.setOnClickListener { onSelectIp(row.ip) }
                    del.setOnClickListener { onDeleteIp(row.groupId, row.ip) }
                }
            }
        }
    }
}
