package com.geofree.android.ui

import android.app.Activity
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.geofree.android.R
import com.geofree.android.data.Prefs
import com.geofree.android.databinding.FragmentMainBinding
import com.geofree.android.vpn.GeoFreeVpnService
import com.geofree.android.vpn.VpnState
import com.google.android.material.button.MaterialButton

class MainFragment : Fragment() {

    private var _b: FragmentMainBinding? = null
    private val b get() = _b!!
    private lateinit var prefs: Prefs

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            GeoFreeVpnService.start(requireContext())
            b.tvLog.text = "Запуск…"
            // статус обновится когда сервис реально поднимет VPN
            b.root.postDelayed({ refreshUi() }, 600)
        } else {
            b.tvLog.text = "Нужно разрешить VPN в системе"
            refreshUi()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentMainBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        prefs = Prefs(requireContext())
        prefs.loadServiceFlags()
        refreshUi()
        b.btnToggle.setOnClickListener { toggle() }
    }

    override fun onResume() {
        super.onResume()
        if (_b != null) refreshUi()
    }

    private fun refreshUi() {
        val on = VpnState.running.get()
        prefs.enabled = on

        b.tvRoot.visibility = View.GONE

        b.tvStatus.text = if (on) "Включено" else "Выключено"
        b.tvStatus.setTextColor(
            Color.parseColor(if (on) "#22C55E" else "#94A3B8")
        )
        b.tvCurrentIp.text = prefs.selectedIp

        b.btnToggle.text = if (on) "Выключить" else "Включить"
        styleToggle(on)
    }

    private fun styleToggle(on: Boolean) {
        val btn = b.btnToggle as MaterialButton
        if (on) {
            btn.backgroundTintList = ContextCompat.getColorStateList(requireContext(), R.color.accent_green)
            btn.setTextColor(Color.WHITE)
        } else {
            btn.backgroundTintList = ContextCompat.getColorStateList(requireContext(), R.color.bg_hover)
            btn.setTextColor(Color.parseColor("#94A3B8"))
        }
    }

    private fun toggle() {
        if (VpnState.running.get()) {
            GeoFreeVpnService.stop(requireContext())
            b.tvLog.text = "Остановка…"
            b.root.postDelayed({ refreshUi() }, 400)
        } else {
            val prepare = VpnService.prepare(requireContext())
            if (prepare != null) {
                b.tvLog.text = "Запрос разрешения VPN…"
                vpnPermission.launch(prepare)
            } else {
                GeoFreeVpnService.start(requireContext())
                b.tvLog.text = "Запуск…"
                b.root.postDelayed({ refreshUi() }, 600)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
