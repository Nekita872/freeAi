package com.geofree.android.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.geofree.android.R
import com.geofree.android.data.AiCatalog
import com.geofree.android.data.AiService
import com.geofree.android.data.Prefs
import com.geofree.android.databinding.FragmentServicesBinding
import com.google.android.material.materialswitch.MaterialSwitch

class ServicesFragment : Fragment() {

    private var _b: FragmentServicesBinding? = null
    private val b get() = _b!!
    private lateinit var prefs: Prefs

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentServicesBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        prefs = Prefs(requireContext())
        prefs.loadServiceFlags()
        b.rvServices.layoutManager = LinearLayoutManager(requireContext())
        b.rvServices.adapter = Adapter(AiCatalog.services) { svc, on ->
            svc.enabled = on
            prefs.setServiceOn(svc.id, on)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private class Adapter(
        private val items: List<AiService>,
        private val onToggle: (AiService, Boolean) -> Unit
    ) : RecyclerView.Adapter<Adapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.tvName)
            val domains: TextView = v.findViewById(R.id.tvDomains)
            val sw: MaterialSwitch = v.findViewById(R.id.swEnabled)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_service, parent, false)
            return VH(v)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.name.text = item.name
            holder.domains.text = item.domains.take(3).joinToString(", ") +
                if (item.domains.size > 3) " +" else ""
            holder.sw.setOnCheckedChangeListener(null)
            holder.sw.isChecked = item.enabled
            holder.sw.setOnCheckedChangeListener { _, checked ->
                onToggle(item, checked)
            }
        }
    }
}
