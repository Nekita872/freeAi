package com.geofree.android.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer

data class IpTestResult(
    val ip: String,
    val ok: Boolean,
    val latencyMs: Long,
    val note: String
)

object IpTester {

    private val SMART_DNS = listOf(
        "212.109.195.93",
        "94.250.253.55"
    )

    /** Хосты, для которых нужна своя A-запись */
    val LOOKUP_HOSTS = listOf(
        "chatgpt.com",
        "ab.chatgpt.com",
        "auth.openai.com",
        "api.openai.com",
        "grok.com",
        "x.ai",
        "accounts.x.ai",
        "claude.ai",
        "anthropic.com",
        "gemini.google.com",
        "aistudio.google.com",
        "copilot.microsoft.com"
    )

    suspend fun test(ip: String): IpTestResult = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        val tcpOk = try {
            java.net.Socket().use { s ->
                s.connect(java.net.InetSocketAddress(ip, 443), 3000)
                true
            }
        } catch (_: Exception) {
            false
        }
        val ms = System.currentTimeMillis() - t0
        if (!tcpOk) return@withContext IpTestResult(ip, false, ms, "TCP 443 нет")
        IpTestResult(ip, true, ms, "TCP 443 OK")
    }

    /**
     * domain -> list of IPs from Smart DNS (на телефоне, без ПК).
     */
    suspend fun resolveDomainMap(): Map<String, String> = withContext(Dispatchers.IO) {
        val map = linkedMapOf<String, String>()
        for (dns in SMART_DNS) {
            for (host in LOOKUP_HOSTS) {
                if (map.containsKey(host)) continue
                try {
                    val ips = dnsQueryA(host, dns)
                    val first = ips.firstOrNull() ?: continue
                    map[host.lowercase()] = first
                } catch (_: Exception) {
                }
            }
        }
        map
    }

    suspend fun pickBest(ips: List<String>): IpTestResult? {
        var best: IpTestResult? = null
        for (ip in ips.distinct()) {
            val r = test(ip)
            if (r.ok && (best == null || r.latencyMs < best.latencyMs)) best = r
        }
        return best
    }

    private fun dnsQueryA(hostname: String, dnsServer: String): List<String> {
        val labels = hostname.trimEnd('.').split('.')
        val q = ByteBuffer.allocate(512)
        q.putShort(0x1234.toShort())
        q.putShort(0x0100.toShort())
        q.putShort(1)
        q.putShort(0); q.putShort(0); q.putShort(0)
        for (lab in labels) {
            val bytes = lab.toByteArray(Charsets.US_ASCII)
            q.put(bytes.size.toByte())
            q.put(bytes)
        }
        q.put(0)
        q.putShort(1)
        q.putShort(1)
        val query = q.array().copyOf(q.position())

        DatagramSocket().use { socket ->
            socket.soTimeout = 3000
            val server = InetAddress.getByName(dnsServer)
            socket.send(DatagramPacket(query, query.size, server, 53))
            val buf = ByteArray(2048)
            val resp = DatagramPacket(buf, buf.size)
            socket.receive(resp)
            return parseARecords(buf, resp.length)
        }
    }

    private fun parseARecords(data: ByteArray, len: Int): List<String> {
        if (len < 12) return emptyList()
        val ancount = ((data[6].toInt() and 0xff) shl 8) or (data[7].toInt() and 0xff)
        var i = 12
        while (i < len) {
            val lab = data[i].toInt() and 0xff
            if (lab == 0) { i++; break }
            if (lab and 0xc0 == 0xc0) { i += 2; break }
            i += 1 + lab
        }
        if (i + 4 <= len) i += 4
        val ips = mutableListOf<String>()
        repeat(ancount) {
            if (i >= len) return@repeat
            val lab = data[i].toInt() and 0xff
            if (lab and 0xc0 == 0xc0) i += 2
            else {
                while (i < len) {
                    val l = data[i].toInt() and 0xff
                    if (l == 0) { i++; break }
                    if (l and 0xc0 == 0xc0) { i += 2; break }
                    i += 1 + l
                }
            }
            if (i + 10 > len) return@repeat
            val type = ((data[i].toInt() and 0xff) shl 8) or (data[i + 1].toInt() and 0xff)
            i += 8
            val rdlen = ((data[i].toInt() and 0xff) shl 8) or (data[i + 1].toInt() and 0xff)
            i += 2
            if (type == 1 && rdlen == 4 && i + 4 <= len) {
                ips += "${data[i].toInt() and 0xff}.${data[i + 1].toInt() and 0xff}.${data[i + 2].toInt() and 0xff}.${data[i + 3].toInt() and 0xff}"
            }
            i += rdlen
        }
        return ips
    }
}
