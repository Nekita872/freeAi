package com.geofree.android.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import android.util.Log
import androidx.core.app.NotificationCompat
import com.geofree.android.R
import com.geofree.android.data.AiCatalog
import com.geofree.android.data.Prefs
import com.geofree.android.vpn.VpnState
import com.geofree.android.ui.MainActivity
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * DNS-only VPN: система шлёт DNS на 10.0.0.1, мы отвечаем.
 * AI-домены -> выбранный IP; остальное -> 8.8.8.8 / 1.1.1.1.
 * Весь остальной трафик НЕ в туннеле.
 */
class GeoFreeVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)

    private lateinit var prefs: Prefs
    private var domainMap: Map<String, ByteArray> = emptyMap() // domain -> ipv4 bytes
    private var fallbackIp: ByteArray = byteArrayOf(206.toByte(), 223.toByte(), 251.toByte(), 18.toByte())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        prefs = Prefs(this)
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> startVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        if (running.get()) return
        prefs.loadServiceFlags()
        val raw = prefs.loadDomainMap()
        val built = linkedMapOf<String, ByteArray>()
        for ((dom, ipStr) in raw) {
            parseIp(ipStr)?.let { built[dom.lowercase()] = it }
        }
        // также все домены из включённых сервисов → fallback, если нет точной записи
        val fb = parseIp(prefs.selectedIp) ?: parseIp("206.223.251.18")!!
        fallbackIp = fb
        for (d in AiCatalog.enabledDomains()) {
            val key = d.lowercase()
            if (!built.containsKey(key)) built[key] = fb
        }
        domainMap = built
        Log.i(TAG, "domain map size=${domainMap.size}")

        val builder = Builder()
            .setSession("GeoFree")
            .setMtu(1500)
            .addAddress("10.0.0.2", 32)
            .addDnsServer("10.0.0.1")
            .addRoute("10.0.0.1", 32)
            .setBlocking(true)

        // Только IPv4 DNS — меньше сюрпризов на Honor
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                builder.allowFamily(OsConstants.AF_INET)
            }
        } catch (_: Exception) {}

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }

        tun = try {
            builder.establish()
        } catch (e: Exception) {
            Log.e(TAG, "establish failed", e)
            null
        }

        if (tun == null) {
            VpnState.running.set(false)
            prefs.enabled = false
            stopSelf()
            return
        }

        prefs.enabled = true
        VpnState.running.set(true)
        startForeground(NOTIF_ID, buildNotification())
        running.set(true)

        thread(name = "geofree-tun", isDaemon = true) {
            packetLoop(tun!!)
        }
    }

    private fun stopVpn() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        try { prefs.enabled = false } catch (_: Exception) {}
        VpnState.running.set(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    private fun packetLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)

        while (running.get()) {
            val len = try { input.read(buf) } catch (_: Exception) { break }
            if (len <= 0) continue
            try {
                handlePacket(buf, len, output)
            } catch (e: Exception) {
                Log.w(TAG, "pkt: ${e.message}")
            }
        }
    }

    private fun handlePacket(packet: ByteArray, len: Int, output: FileOutputStream) {
        if ((packet[0].toInt() ushr 4) != 4) return
        val ihl = (packet[0].toInt() and 0x0f) * 4
        if (len < ihl + 8) return
        if ((packet[9].toInt() and 0xff) != 17) return // UDP

        val srcPort = u16(packet, ihl)
        val dstPort = u16(packet, ihl + 2)
        if (dstPort != 53) return

        val dnsQuery = packet.copyOfRange(ihl + 8, len)
        val dnsResp = resolveDns(dnsQuery) ?: return
        val outPkt = buildIpUdpResponse(packet, ihl, srcPort, dnsResp)
        output.write(outPkt)
    }

    private fun resolveDns(query: ByteArray): ByteArray? {
        val name = parseDnsName(query)
        if (name != null && isAQuery(query)) {
            val lower = name.lowercase().trimEnd('.')
            val ip = findIpForHost(lower)
            if (ip != null) {
                Log.i(TAG, "AI map: $lower")
                return buildAResponse(query, ip)
            }
        }
        return forwardDns(query, "8.8.8.8")
            ?: forwardDns(query, "1.1.1.1")
            ?: forwardDns(query, "9.9.9.9")
    }

    private fun findIpForHost(host: String): ByteArray? {
        domainMap[host]?.let { return it }
        // suffix match: chat.openai.com under openai.com style
        for ((dom, ip) in domainMap) {
            if (host == dom || host.endsWith(".$dom")) return ip
        }
        return null
    }

    private fun forwardDns(query: ByteArray, server: String): ByteArray? {
        return try {
            DatagramSocket().use { socket ->
                protect(socket)
                socket.soTimeout = 2500
                val addr = InetAddress.getByName(server)
                socket.send(DatagramPacket(query, query.size, addr, 53))
                val buf = ByteArray(4096)
                val resp = DatagramPacket(buf, buf.size)
                socket.receive(resp)
                buf.copyOf(resp.length)
            }
        } catch (e: Exception) {
            Log.w(TAG, "forward $server: ${e.message}")
            null
        }
    }

    private fun parseDnsName(query: ByteArray): String? {
        if (query.size < 13) return null
        var i = 12
        val sb = StringBuilder()
        var jumps = 0
        while (i < query.size && jumps < 10) {
            val lab = query[i].toInt() and 0xff
            if (lab == 0) break
            if (lab and 0xc0 == 0xc0) break
            if (i + 1 + lab > query.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(query, i + 1, lab, Charsets.US_ASCII))
            i += 1 + lab
            jumps++
        }
        return sb.toString().ifEmpty { null }
    }

    private fun isAQuery(query: ByteArray): Boolean {
        var i = 12
        while (i < query.size) {
            val lab = query[i].toInt() and 0xff
            if (lab == 0) { i++; break }
            if (lab and 0xc0 == 0xc0) { i += 2; break }
            i += 1 + lab
        }
        if (i + 2 > query.size) return true
        return u16(query, i) == 1
    }

    private fun buildAResponse(query: ByteArray, ip: ByteArray): ByteArray {
        val out = ByteBuffer.allocate(512)
        out.put(query[0]); out.put(query[1])
        out.put(0x81.toByte()); out.put(0x80.toByte()) // QR RD RA
        out.put(query[4]); out.put(query[5]) // qdcount
        out.put(0); out.put(1) // ancount
        out.put(0); out.put(0); out.put(0); out.put(0)
        // copy question
        var i = 12
        while (i < query.size) {
            val lab = query[i].toInt() and 0xff
            out.put(query[i])
            if (lab == 0) { i++; break }
            if (lab and 0xc0 == 0xc0) {
                if (i + 1 < query.size) out.put(query[i + 1])
                i += 2
                break
            }
            var k = 1
            while (k <= lab && i + k < query.size) {
                out.put(query[i + k]); k++
            }
            i += 1 + lab
        }
        if (i + 4 <= query.size) {
            out.put(query, i, 4)
        } else {
            out.put(0); out.put(1); out.put(0); out.put(1)
        }
        // answer
        out.put(0xc0.toByte()); out.put(0x0c)
        out.put(0); out.put(1) // A
        out.put(0); out.put(1) // IN
        out.putInt(60) // TTL
        out.put(0); out.put(4)
        out.put(ip)
        return out.array().copyOf(out.position())
    }

    private fun buildIpUdpResponse(
        original: ByteArray,
        ihl: Int,
        clientPort: Int,
        dnsPayload: ByteArray
    ): ByteArray {
        val totalLen = ihl + 8 + dnsPayload.size
        val out = ByteArray(totalLen)
        out[0] = 0x45
        out[2] = (totalLen ushr 8).toByte()
        out[3] = (totalLen and 0xff).toByte()
        out[8] = 64
        out[9] = 17
        // swap IP
        System.arraycopy(original, 16, out, 12, 4)
        System.arraycopy(original, 12, out, 16, 4)
        // UDP
        val udpLen = 8 + dnsPayload.size
        out[ihl] = 0
        out[ihl + 1] = 53
        out[ihl + 2] = (clientPort ushr 8).toByte()
        out[ihl + 3] = (clientPort and 0xff).toByte()
        out[ihl + 4] = (udpLen ushr 8).toByte()
        out[ihl + 5] = (udpLen and 0xff).toByte()
        out[ihl + 6] = 0
        out[ihl + 7] = 0 // UDP checksum 0 = optional in IPv4
        System.arraycopy(dnsPayload, 0, out, ihl + 8, dnsPayload.size)
        val csum = ipChecksum(out, ihl)
        out[10] = (csum ushr 8).toByte()
        out[11] = (csum and 0xff).toByte()
        return out
    }

    private fun ipChecksum(buf: ByteArray, headerLen: Int): Int {
        var sum = 0
        var i = 0
        while (i < headerLen) {
            if (i == 10) { i += 2; continue }
            sum += u16(buf, i)
            i += 2
        }
        while (sum ushr 16 != 0) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv() and 0xffff
    }

    private fun u16(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xff) shl 8) or (b[off + 1].toInt() and 0xff)

    private fun parseIp(s: String): ByteArray? {
        val p = s.trim().split('.')
        if (p.size != 4) return null
        return try {
            byteArrayOf(
                p[0].toInt().toByte(),
                p[1].toInt().toByte(),
                p[2].toInt().toByte(),
                p[3].toInt().toByte()
            )
        } catch (_: Exception) { null }
    }

    private fun buildNotification(): Notification {
        val channelId = "geofree_vpn"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "GeoFree VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("GeoFree")
            .setContentText("DNS для AI включён")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val TAG = "GeoFreeVpn"
        const val ACTION_STOP = "com.geofree.android.STOP"
        private const val NOTIF_ID = 42

        fun start(context: Context) {
            val i = Intent(context, GeoFreeVpnService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i)
            else context.startService(i)
        }

        fun stop(context: Context) {
            context.startService(Intent(context, GeoFreeVpnService::class.java).setAction(ACTION_STOP))
        }
    }
}
