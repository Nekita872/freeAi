package com.geofree.android.vpn

import java.util.concurrent.atomic.AtomicBoolean

/** Реальный статус VPN-сервиса (не только prefs). */
object VpnState {
    val running = AtomicBoolean(false)
}
